# CShield SDK

SDK bảo mật cho Node.js/Express - cung cấp middleware xác thực chữ ký request (RSA-SHA256) và ký response tự động.

## Mục lục

- [Tổng quan](#tổng-quan)
- [Cài đặt](#cài-đặt)
- [Quick Start](#quick-start)
- [Hai cách sử dụng](#hai-cách-sử-dụng)
- [Key Providers](#key-providers)
- [Xử lý lỗi (Exceptions)](#xử-lý-lỗi-exceptions)
- [Tùy chỉnh nâng cao](#tùy-chỉnh-nâng-cao)
- [API Reference](#api-reference)
- [Lưu ý quan trọng](#lưu-ý-quan-trọng)

## Tổng quan

CShield SDK bảo vệ API server bằng cơ chế chữ ký số RSA-SHA256:

- **Verify request**: Kiểm tra header `cs-timestamp` và `cs-signature` trên mỗi request đến, đảm bảo request không bị giả mạo hoặc replay.
- **Sign response**: Tự động ký response trước khi trả về client, để client có thể xác thực response từ server.
- **Error handling**: Trả về lỗi chuẩn JSON kèm chữ ký khi request không hợp lệ.

### Cơ chế hoạt động

```
Client → [cs-timestamp + cs-signature headers] → Server
  Server verify: METHOD.path.timestamp.SHA256(body) → RSA-SHA256 verify bằng public key

Server → [cs-timestamp + cs-signature headers] → Client
  Server sign: status.path.timestamp.SHA256(body) → RSA-SHA256 sign bằng private key
```

## Cài đặt

```bash
npm install cshield-sdk
```

**Yêu cầu**: Express >= 4.0.0 (peerDependency)

## Quick Start

```javascript
const express = require("express");
const {
  CShield,
  DefaultRequestVerifier,
  DefaultResponseSigner,
  DefaultPublicKeyProvider,
  DefaultPrivateKeyProvider,
} = require("cshield-sdk");

const app = express();
app.use(express.json()); // Bắt buộc phải có trước CShield

// 1. Tạo key providers
const publicKeyProvider = new DefaultPublicKeyProvider(process.env.PUBLIC_KEY);
const privateKeyProvider = new DefaultPrivateKeyProvider(process.env.PRIVATE_KEY);

// 2. Khởi tạo CShield
const shield = new CShield({
  requestVerifier: new DefaultRequestVerifier(publicKeyProvider),
  responseSigner: new DefaultResponseSigner(privateKeyProvider),
});

// 3. Gắn middleware vào route cần bảo vệ
app.post("/api/verify-otp", ...shield.middlewares(), (req, res) => {
  res.json({ success: true, message: "OTP hợp lệ" });
});

// 4. Gắn error handler (phải đặt sau tất cả route)
app.use(shield.errorHandler());

app.listen(8080);
```

## Hai cách sử dụng

### Cách 1: CShield facade (khuyến nghị)

Cách đơn giản nhất — tạo một instance `CShield` rồi dùng `middlewares()` và `errorHandler()`:

```javascript
const shield = new CShield({
  requestVerifier: new DefaultRequestVerifier(publicKeyProvider),
  responseSigner: new DefaultResponseSigner(privateKeyProvider),
  // Tùy chọn:
  // verifyRequest: true,   // default: true
  // signResponse: true,    // default: true
  // errorWriter: customErrorWriter,
});

// Gắn verify + sign middleware
app.post("/protected", ...shield.middlewares(), handler);

// Error handler
app.use(shield.errorHandler());
```

**Tùy chọn CShieldOptions:**

| Field | Type | Default | Mô tả |
|-------|------|---------|-------|
| `requestVerifier` | `RequestVerifier` (abstract class) | *bắt buộc* | Bộ xác thực request |
| `responseSigner` | `ResponseSigner` (abstract class) | *bắt buộc* | Bộ ký response |
| `verifyRequest` | `boolean` | `true` | Có verify request hay không |
| `signResponse` | `boolean` | `true` | Có sign response hay không |
| `errorWriter` | `CShieldErrorWriter` | `DefaultErrorWriter` | Bộ ghi lỗi tùy chỉnh |

### Cách 2: Middleware riêng lẻ (linh hoạt hơn)

Dùng khi cần kiểm soát chi tiết — ví dụ route A chỉ verify, route B chỉ sign:

```javascript
const {
  verifyMiddleware,
  signMiddleware,
  errorHandlerMiddleware,
  DefaultErrorWriter,
} = require("cshield-sdk");

// Route chỉ verify request, không sign response
app.post("/upload",
  verifyMiddleware(requestVerifier),
  uploadHandler
);

// Route chỉ sign response, không verify request
app.get("/public-data",
  signMiddleware(responseSigner),
  dataHandler
);

// Route verify + sign
app.post("/transfer",
  verifyMiddleware(requestVerifier),
  signMiddleware(responseSigner),
  transferHandler
);

// Error handler (đặt cuối cùng)
const errorWriter = new DefaultErrorWriter(responseSigner, true);
app.use(errorHandlerMiddleware(errorWriter));
```

## Key Providers

Key provider cung cấp RSA key cho SDK. SDK cung cấp sẵn `DefaultPublicKeyProvider` và `DefaultPrivateKeyProvider` nhận key string trực tiếp.

### Dùng Default Provider

```javascript
// Đọc key từ environment variable (khuyến nghị cho production)
const publicKeyProvider = new DefaultPublicKeyProvider(process.env.PUBLIC_KEY);
const privateKeyProvider = new DefaultPrivateKeyProvider(process.env.PRIVATE_KEY);

// Hoặc đọc key từ file (dùng cho development)
const fs = require("fs");
const publicKey = fs.readFileSync("keys/public.pem", "utf8");
const publicKeyProvider = new DefaultPublicKeyProvider(publicKey);
```

### Tự viết Key Provider

Implement interface `PublicKeyProvider` hoặc `PrivateKeyProvider` để lấy key từ nguồn khác (database, Redis, KMS...):

```typescript
import { PublicKeyProvider } from "cshield-sdk";

class RedisPublicKeyProvider implements PublicKeyProvider {
  constructor(private redis: Redis) {}

  load(): string {
    // Lấy key từ Redis, database, hoặc bất kỳ nguồn nào
    return this.redis.get("cshield:public_key");
  }
}
```

## Xử lý lỗi (Exceptions)

SDK throw các exception cụ thể khi xác thực thất bại. Tất cả đều kế thừa từ `RuntimeException`:

| Exception | Khi nào | HTTP Status mặc định |
|-----------|---------|---------------------|
| `MissingSignatureHeaderException` | Thiếu header `cs-timestamp` hoặc `cs-signature` | 400 |
| `TimeoutRequestException` | Request hết hạn (timestamp quá cũ hoặc quá mới) | 408 |
| `InvalidSignatureException` | Chữ ký không hợp lệ | 401 |
| `ResponseSignerException` | Lỗi khi ký response (key sai format...) | 500 |

### Bắt exception cụ thể

```javascript
const {
  InvalidSignatureException,
  TimeoutRequestException,
  MissingSignatureHeaderException,
} = require("cshield-sdk");

app.use((err, req, res, next) => {
  if (err instanceof MissingSignatureHeaderException) {
    return res.status(400).json({ error: "Thiếu header chữ ký" });
  }
  if (err instanceof TimeoutRequestException) {
    return res.status(408).json({ error: "Request hết hạn" });
  }
  if (err instanceof InvalidSignatureException) {
    return res.status(401).json({ error: "Chữ ký không hợp lệ" });
  }
  next(err);
});
```

## Tùy chỉnh nâng cao

### Custom RequestVerifier

`RequestVerifier` là abstract class đã tích hợp sẵn RSA-SHA256 và logic kiểm tra timeout/missing header. Để thay đổi payload format, extend và override `buildPayload()`:

```typescript
import { RequestVerifier } from "cshield-sdk";

class CustomRequestVerifier extends RequestVerifier {
  protected buildPayload(
    method: string,
    path: string,
    timestamp: string,
    bodyHash: string
  ): string {
    // Ví dụ: thêm prefix vào payload
    return `v2.${method}.${path}.${timestamp}.${bodyHash}`;
  }
}

// Dùng giống DefaultRequestVerifier
const verifier = new CustomRequestVerifier(publicKeyProvider, 60);
```

### Custom ResponseSigner

`ResponseSigner` là abstract class đã tích hợp sẵn RSA-SHA256. Để thay đổi payload format, extend và override `buildPayload()`:

```typescript
import { ResponseSigner } from "cshield-sdk";

class CustomResponseSigner extends ResponseSigner {
  protected buildPayload(
    bodyHash: string,
    status: number,
    timestamp: string,
    path: string
  ): string {
    // Ví dụ: thêm prefix vào payload
    return `v2.${status}.${path}.${timestamp}.${bodyHash}`;
  }
}

// Dùng giống DefaultResponseSigner
const signer = new CustomResponseSigner(privateKeyProvider);
```

### Custom ErrorWriter

Kế thừa `CShieldErrorWriter` để thay đổi format lỗi trả về:

```typescript
import { CShieldErrorWriter } from "cshield-sdk";
import { Response } from "express";

class CustomErrorWriter extends CShieldErrorWriter {
  writeError(
    reqPath: string,
    res: Response,
    status: number,
    code: string,
    message: string
  ): void {
    const body = JSON.stringify({
      error: { code, message, path: reqPath },
    });

    res.status(status);
    res.setHeader("Content-Type", "application/json");

    if (this.signResponse) {
      this.attachSignature(res, body, status, reqPath);
    }

    res.send(body);
  }
}
```

## API Reference

### Middleware

| Function | Tham số | Mô tả |
|----------|---------|-------|
| `verifyMiddleware(verifier)` | `RequestVerifier` | Xác thực chữ ký request |
| `signMiddleware(signer)` | `ResponseSigner` | Ký response tự động |
| `errorHandlerMiddleware(writer)` | `CShieldErrorWriter` | Xử lý lỗi CShield |

### Headers

SDK sử dụng 2 custom headers:

| Header | Mô tả |
|--------|-------|
| `cs-timestamp` | Unix timestamp (giây) của request/response |
| `cs-signature` | Chữ ký RSA-SHA256 (base64) |

## Lưu ý quan trọng

1. **`express.json()` phải được gọi trước middleware CShield** — SDK cần `req.body` đã được parse để tính hash.

2. **Body hash dựa trên `JSON.stringify(req.body)`** — SDK hash lại body sau khi Express parse JSON. Client và server phải thống nhất cách serialize body để hash khớp.

3. **Timeout mặc định là 30 giây** — Request có timestamp cách thời điểm hiện tại hơn 30 giây (cả quá khứ lẫn tương lai) sẽ bị từ chối. Tùy chỉnh:
   ```javascript
   new DefaultRequestVerifier(publicKeyProvider, 60); // 60 giây
   ```

4. **Error handler phải đặt sau tất cả route** — Đây là quy ước của Express cho error handling middleware.
