# CShield SDK

SDK bảo mật cho Node.js/Express — xác thực chữ ký request (RSA-SHA256), ký response tự động, và kiểm soát license server-side thông qua Rust native core.

## Mục lục

- [Tổng quan](#tổng-quan)
- [Cài đặt](#cài-đặt)
- [Quick Start](#quick-start)
- [License](#license)
- [Middleware](#middleware)
- [Key Providers](#key-providers)
- [Xử lý lỗi (Exceptions)](#xử-lý-lỗi-exceptions)
- [Tùy chỉnh nâng cao](#tùy-chỉnh-nâng-cao)
- [API Reference](#api-reference)
- [Lưu ý quan trọng](#lưu-ý-quan-trọng)

## Tổng quan

CShield SDK bảo vệ API server bằng hai lớp:

1. **License validation** — JWT license được kiểm tra bởi Rust binary (không thể monkey-patch từ JS). SDK từ chối khởi động nếu license không hợp lệ.
2. **Request/response signing** — Mỗi request phải có header `cs-timestamp` + `cs-signature` (RSA-SHA256). Response được ký tự động.

### Cơ chế hoạt động

```
Startup: CShield.create(config)
  → Rust validate license JWT locally
  → POST /license/validate → Rust verify server response JWT
  → Heartbeat timer started (auto-renew)
  → Instance trả về chỉ khi license hợp lệ

Mỗi request:
  → Rust gate (cshield_check_license_status) → allow / block
  → Verify: METHOD.path.timestamp.SHA256(body) → RSA-SHA256 verify
  → Handler
  → Sign: status.path.timestamp.SHA256(body) → RSA-SHA256 sign
```

## Cài đặt

```bash
npm install cshield-sdk.tgz
```

**Yêu cầu**: Node.js >= 16, Express >= 4.0.0

## Quick Start

```javascript
require("dotenv").config();
const express = require("express");
const {
  CShield,
  DefaultRequestVerifier,
  DefaultResponseSigner,
  DefaultPublicKeyProvider,
  DefaultPrivateKeyProvider,
} = require("cshield-sdk");

const app = express();
app.use(express.json()); // Bắt buộc phải có trước CShield

const publicKeyProvider  = new DefaultPublicKeyProvider(process.env.CSHIELD_PUBLIC_KEY);
const privateKeyProvider = new DefaultPrivateKeyProvider(process.env.CSHIELD_PRIVATE_KEY);
const requestVerifier    = new DefaultRequestVerifier(publicKeyProvider);
const responseSigner     = new DefaultResponseSigner(privateKeyProvider);

async function startServer() {
  // CShield.create() validate license trước khi trả về instance.
  // Throw nếu license không hợp lệ / hết hạn / server từ chối.
  const cshield = await CShield.create({
    license: {
      licenseKey: process.env.CSHIELD_LICENSE_KEY,
      onStatusChange: (status) => console.log("[CShield] Status:", status),
      onRenew: async (newToken) => { /* lưu token mới */ },
    },
  });

  console.log("License status:", cshield.getLicenseStatus());

  // Route được bảo vệ — Rust gate chạy trên mỗi request
  app.post("/api/verify-otp",
    cshield.verifyMiddleware(requestVerifier),
    cshield.signMiddleware(responseSigner),
    (req, res) => {
      res.json({ success: true });
    },
  );

  // Error handler — phải đặt sau tất cả route
  app.use(cshield.errorHandler());

  // Graceful shutdown
  process.on("SIGTERM", () => { cshield.shutdown(); process.exit(0); });
  process.on("SIGINT",  () => { cshield.shutdown(); process.exit(0); });

  app.listen(8080);
}

startServer().catch((err) => {
  console.error("License validation failed:", err.message);
  process.exit(1);
});
```

## License

### CShieldConfig

```typescript
interface CShieldConfig {
  license: LicenseConfig;          // Bắt buộc
  errorWriter?: CShieldErrorWriter; // Tùy chọn — custom error format
}
```

### LicenseConfig

| Field | Type | Mặc định | Mô tả |
|-------|------|----------|-------|
| `licenseKey` | `string` | *bắt buộc* | Raw JWT string của license |
| `gracePath` | `string` | `./.cshield.grace` | Đường dẫn file grace state (offline fallback) |
| `appId` | `{ ios: string; android: string }` | — | Giới hạn license theo bundle ID / package name |
| `onStatusChange` | `(status: LicenseStatus) => void` | — | Callback khi trạng thái license thay đổi |
| `onRenew` | `(newToken: string) => Promise<void>` | — | Callback khi license được gia hạn tự động |
| `maxGraceBoots` | `number` | `10` | Số lần khởi động offline tối đa trong grace period |

### LicenseStatus

```typescript
enum LicenseStatus {
  VALID        = "VALID",
  GRACE_PERIOD = "GRACE_PERIOD",  // Server không liên lạc được, đang dùng offline grace
  EXPIRED      = "EXPIRED",
  REVOKED      = "REVOKED",
  INVALID      = "INVALID",
}
```

### Offline grace period

Khi server không thể kết nối (`/license/validate`), SDK chuyển sang **grace period** thay vì tắt ngay:

```
Server unreachable
  → Tạo / đọc grace file (mã hoá AES-256-GCM, gắn với machine ID)
  → Tiếp tục hoạt động tối đa `grace_hours` giờ hoặc `maxGraceBoots` lần restart
  → Khi hết grace → throw LicenseExpiredException → server dừng
```

Grace state file mã hoá theo machine ID — không thể copy sang máy khác để bypass.

## Middleware

### Instance methods (khuyến nghị — có Rust gate)

```javascript
const cshield = await CShield.create({ license: { licenseKey: '...' } });

// Verify request + Rust license gate
app.post("/route", cshield.verifyMiddleware(requestVerifier), handler);

// Sign response + Rust license gate
app.post("/route", cshield.signMiddleware(responseSigner), handler);

// Verify + Sign cùng lúc
app.post("/route", ...cshield.middlewares(requestVerifier, responseSigner), handler);

// Error handler (đặt cuối cùng)
app.use(cshield.errorHandler());
```

### Standalone functions (không có Rust gate — dùng khi không cần license)

```javascript
const { verifyMiddleware, signMiddleware, errorHandlerMiddleware } = require("cshield-sdk");

app.post("/route", verifyMiddleware(requestVerifier), handler);
app.post("/route", signMiddleware(responseSigner), handler);
app.use(errorHandlerMiddleware());
```

## Key Providers

Key provider cung cấp RSA key cho SDK. SDK cung cấp sẵn `DefaultPublicKeyProvider` và `DefaultPrivateKeyProvider` nhận key string trực tiếp.

### Dùng Default Provider

```javascript
// Từ environment variable (khuyến nghị cho production)
// Key phải là PEM base64-encoded: base64 -w 0 private.pem
const privateKey = Buffer.from(process.env.CSHIELD_PRIVATE_KEY, "base64").toString("utf8");
const publicKey  = Buffer.from(process.env.CSHIELD_PUBLIC_KEY,  "base64").toString("utf8");

const privateKeyProvider = new DefaultPrivateKeyProvider(privateKey);
const publicKeyProvider  = new DefaultPublicKeyProvider(publicKey);
```

### Tự viết Key Provider

Implement interface `PublicKeyProvider` hoặc `PrivateKeyProvider` để lấy key từ nguồn khác (database, Redis, KMS...):

```typescript
import { PublicKeyProvider } from "cshield-sdk";

class RedisPublicKeyProvider implements PublicKeyProvider {
  constructor(private redis: Redis) {}

  load(): string {
    return this.redis.get("cshield:public_key");
  }
}
```

## Xử lý lỗi (Exceptions)

Tất cả exception kế thừa từ `RuntimeException`. SDK tự động map về HTTP status trong `errorHandler()`.

### Signature exceptions

| Exception | Khi nào | HTTP Status |
|-----------|---------|-------------|
| `MissingSignatureHeaderException` | Thiếu header `cs-timestamp` hoặc `cs-signature` | 400 |
| `TimeoutRequestException` | Timestamp lệch quá ngưỡng cho phép | 408 |
| `InvalidSignatureException` | Chữ ký RSA-SHA256 không khớp | 401 |

### License exceptions

| Exception | Khi nào | HTTP Status |
|-----------|---------|-------------|
| `LicenseExpiredException` | License hết hạn hoặc grace period kết thúc | 403 |
| `LicenseRevokedException` | License bị thu hồi bởi server | 403 |
| `InvalidLicenseException` | JWT không hợp lệ, server response bị giả mạo | 403 |

### Bắt exception thủ công

```javascript
const {
  InvalidSignatureException,
  TimeoutRequestException,
  LicenseExpiredException,
  LicenseRevokedException,
} = require("cshield-sdk");

app.use((err, req, res, next) => {
  if (err instanceof LicenseExpiredException) {
    return res.status(403).json({ code: "LICENSE_EXPIRED" });
  }
  if (err instanceof LicenseRevokedException) {
    return res.status(403).json({ code: "LICENSE_REVOKED" });
  }
  if (err instanceof InvalidSignatureException) {
    return res.status(401).json({ code: "UNAUTHORIZED" });
  }
  next(err);
});
```

## Tùy chỉnh nâng cao

### Custom RequestVerifier

Override `buildPayload()` để thay đổi format payload chữ ký:

```typescript
import { RequestVerifier } from "cshield-sdk";

class CustomRequestVerifier extends RequestVerifier {
  protected buildPayload(
    method: string,
    path: string,
    timestamp: string,
    bodyHash: string,
  ): string {
    return `v2.${method}.${path}.${timestamp}.${bodyHash}`;
  }
}

const verifier = new CustomRequestVerifier(publicKeyProvider, 60); // timeout 60s
```

### Custom ResponseSigner

```typescript
import { ResponseSigner } from "cshield-sdk";

class CustomResponseSigner extends ResponseSigner {
  protected buildPayload(
    bodyHash: string,
    status: number,
    timestamp: string,
    path: string,
  ): string {
    return `v2.${status}.${path}.${timestamp}.${bodyHash}`;
  }
}
```

### Custom ErrorWriter

```typescript
import { CShieldErrorWriter } from "cshield-sdk";
import { Response } from "express";

class CustomErrorWriter extends CShieldErrorWriter {
  writeError(reqPath: string, res: Response, status: number, code: string, message: string): void {
    res.status(status).json({ error: { code, message, path: reqPath } });
  }
}

app.use(cshield.errorHandler(new CustomErrorWriter(responseSigner, true)));
```

## API Reference

### `CShield` class

| Method | Trả về | Mô tả |
|--------|--------|-------|
| `CShield.create(config)` | `Promise<CShield>` | Factory — validate license, khởi động heartbeat |
| `cshield.verifyMiddleware(verifier)` | `RequestHandler` | Middleware verify request + Rust gate |
| `cshield.signMiddleware(signer)` | `RequestHandler` | Middleware sign response + Rust gate |
| `cshield.middlewares(verifier, signer)` | `RequestHandler[]` | Cả hai middleware cùng lúc |
| `cshield.errorHandler(writer?)` | `ErrorRequestHandler` | Error handler cho signature + license errors |
| `cshield.getLicenseStatus()` | `LicenseStatus` | Trạng thái license hiện tại |
| `cshield.shutdown()` | `void` | Dừng heartbeat timer, giải phóng Rust handle |

### Standalone middleware functions

| Function | Tham số | Mô tả |
|----------|---------|-------|
| `verifyMiddleware(verifier)` | `RequestVerifier` | Verify chữ ký request (không có Rust gate) |
| `signMiddleware(signer)` | `ResponseSigner` | Ký response (không có Rust gate) |
| `errorHandlerMiddleware(writer?)` | `CShieldErrorWriter?` | Xử lý lỗi CShield |

### Headers

| Header | Mô tả |
|--------|-------|
| `cs-timestamp` | Unix timestamp (giây) của request/response |
| `cs-signature` | Chữ ký RSA-SHA256 (base64) |
| `X-CShield-License` | `grace-period` — xuất hiện khi license đang trong offline grace period |

## Lưu ý quan trọng

1. **`express.json()` phải được gọi trước middleware CShield** — SDK cần `req.body` đã parse để tính hash.

2. **`CShield.create()` là async và có thể throw** — Wrap trong `try/catch`, gọi `process.exit(1)` nếu license không hợp lệ để tránh server chạy không có bảo vệ.

3. **Gọi `cshield.shutdown()` khi tắt server** — Giải phóng Rust native handle và dừng heartbeat timer.

4. **Timeout mặc định là 30 giây** — Request có timestamp lệch hơn 30 giây bị từ chối:
   ```javascript
   new DefaultRequestVerifier(publicKeyProvider, 60); // tăng lên 60 giây
   ```

5. **Body hash dựa trên `JSON.stringify(req.body)`** — Client và server phải serialize body theo cùng một cách để hash khớp.

6. **License key là raw JWT string** — Không phải file path. Đọc từ biến môi trường `CSHIELD_LICENSE_KEY`.
