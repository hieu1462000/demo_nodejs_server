# CShield SDK

Middleware bảo mật cho Express, xác thực toàn vẹn hai chiều giữa client và server trên từng request: server verify chữ ký của request đến, và ký chữ ký cho response trả về.

```
Request:   Client ──[cs-proof]──────────────────▶ Server   (server verify chữ ký thiết bị)
Response:  Client ◀──[cs-timestamp, cs-signature]── Server   (server ký bằng RSA private key)
```

Hai chiều dùng hai cơ chế khác nhau, mỗi chiều một cơ chế duy nhất:

- **Verify request — chữ ký thiết bị** (ECDSA P-256, key phần cứng riêng từng thiết bị: Android Keystore / iOS Secure Enclave). Request được bảo vệ **bắt buộc** có header `cs-proof`; thiếu header này là `400 CSHIELD_MISSING_SIGNATURE_HEADER`, không có luồng verify nào khác để rơi xuống. Public key thiết bị + trustLevel rút từ **access token ES256** trong `cs-proof`, verify **OFFLINE** qua JWKS của realm (SDK chạy **thuần ES256**, không fallback). Server chỉ cần khai **realm của chính mình** — xem [1.1](#11-cấu-hình-realm).
- **Ký response — RSA-SHA256** với private key của server (`PrivateKeyProvider`). Đây là chỗ duy nhất server cần cấu hình khoá.

Chữ ký là hợp đồng hai chiều: chuỗi payload phải khớp tuyệt đối giữa server và client, lệch một byte sẽ verify thất bại.

## Quy ước mật mã

| Thành phần | Verify request | Ký response |
|---|---|---|
| Thuật toán | ECDSA P-256 (secp256r1) + SHA-256 | RSA-SHA256 |
| Header | `cs-proof` (base64 của JSON, xem [1.2](#12-envelope-cs-proof)) | `cs-timestamp`, `cs-signature` |
| Mã hoá chữ ký | base64 (DER) | base64 |
| Khoá | public key THIẾT BỊ, rút từ `cnf.jwk` của access token ES256 (token do khóa realm ký, verify offline qua JWKS) | private key server, do bên tích hợp cấu hình |
| Payload | `METHOD\nPATH\nCANONICAL_QUERY\nTIMESTAMP\nREQUEST_ID\nbodyHash` | `status.path.timestamp.SHA256(body)` |
| Hash body | SHA-256, hex thường | như bên trái — dùng chung một hàm hash |

Cả hai chiều dùng chung một thuật toán canonical hoá `path`/`query`, chỉ khác cách ráp cuối — xem [3.3 Path & query](#33-path--query).

## Mục lục

- [Cài đặt](#cài-đặt)
- [Bắt đầu nhanh](#bắt-đầu-nhanh)
- [1. Verify request — Chữ ký thiết bị](#1-verify-request--chữ-ký-thiết-bị)
  - [1.1 Cấu hình realm](#11-cấu-hình-realm)
  - [1.2 Envelope cs-proof](#12-envelope-cs-proof)
  - [1.3 TrustPolicy — ALLOW/DENY theo trustLevel](#13-trustpolicy--allowdeny-theo-trustlevel)
  - [1.4 Chống replay theo requestId](#14-chống-replay-theo-requestid)
  - [1.5 Exception riêng của verify request](#15-exception-riêng-của-verify-request)
- [2. Ký response — Chữ ký RSA](#2-ký-response--chữ-ký-rsa)
  - [2.1 ResponseSigner](#21-responsesigner)
  - [2.2 KeyProvider](#22-keyprovider)
- [3. Cơ chế chung](#3-cơ-chế-chung)
  - [3.1 CShield & middleware](#31-cshield--middleware)
  - [3.2 Hash body theo loại route](#32-hash-body-theo-loại-route)
  - [3.3 Path & query](#33-path--query)
  - [3.4 Cửa sổ chống replay](#34-cửa-sổ-chống-replay)
  - [3.5 Exception & xử lý lỗi](#35-exception--xử-lý-lỗi)
  - [3.6 Observability](#36-observability)
- [4. Tùy chỉnh](#4-tùy-chỉnh)
  - [4.1 Tùy chỉnh payload ký response](#41-tùy-chỉnh-payload-ký-response)
  - [4.2 Tùy chỉnh KeyProvider](#42-tùy-chỉnh-keyprovider)
  - [4.3 Tùy chỉnh TrustPolicy](#43-tùy-chỉnh-trustpolicy)
  - [4.4 Tùy chỉnh response lỗi](#44-tùy-chỉnh-response-lỗi)
  - [4.5 Lắp middleware rời / tự viết middleware](#45-lắp-middleware-rời--tự-viết-middleware)
- [Tham chiếu API](#tham-chiếu-api)

---

## Cài đặt

```bash
npm install cshield-sdk
```

Yêu cầu: Express >= 4.0.0 (peerDependency).

## Bắt đầu nhanh

```javascript
const express = require("express");
const {
  CShield,
  DefaultRequestVerifier, DefaultResponseSigner,
  DefaultPrivateKeyProvider,
  CShieldEnvironment,
  captureRawBody,
} = require("cshield-sdk");

const app = express();

// Body parser phải kèm verify: captureRawBody (đặt trước route, áp dụng cho mọi parser).
app.use(express.json({ verify: captureRawBody }));
app.use(express.urlencoded({ extended: true, verify: captureRawBody }));

// privateKeyPem: chuỗi PEM private key của server, CHỈ dùng để ký response.
// realm: định danh CHÍNH server này — bắt buộc, server tự pin, KHÔNG lấy từ token client. Dùng
// để verify access token ES256 offline qua JWKS. customerCode/applicationId truyền NGUYÊN như
// trong license; environment dùng CShieldEnvironment.*; SDK tự hạ chữ thường. Xem 1.1.
const shield = new CShield({
  requestVerifier: new DefaultRequestVerifier({
    realm: {
      customerCode: "CMCCS",
      applicationId: "cshield-embedded-sample",
      environment: CShieldEnvironment.DEV,
    },
  }),
  responseSigner: new DefaultResponseSigner(new DefaultPrivateKeyProvider(privateKeyPem)),
  // Ngưỡng trust tối thiểu của THIẾT BỊ cho mọi route (mặc định "L1"). Thiết bị dưới ngưỡng ->
  // 403 CSHIELD_DEVICE_NOT_ALLOWED. ĐỪNG bỏ qua: đây là chốt chặn thiết bị yếu/giả lập. Xem 1.3.
  minTrustLevel: "L2",
});

// Bảo vệ route: verify request (yêu cầu header cs-proof) + ký response.
// Route nhạy cảm có thể siết ngưỡng riêng, cao hơn mặc định của shield:
app.post("/login", ...shield.middlewares(), (req, res) => {
  res.json({ success: true });
});
app.post("/payments", ...shield.middlewares({ minTrustLevel: "L4" }), (req, res) => {
  res.json({ success: true });
});

// Error handler đặt sau cùng.
app.use(shield.errorHandler());

app.listen(8080);
```

---

# 1. Verify request — Chữ ký thiết bị

Chữ ký ký bằng key phần cứng riêng từng thiết bị (Android Keystore / iOS Secure Enclave, ECDSA P-256), gửi trong header `cs-proof`.

> Đây là luồng verify **duy nhất**. "Tuỳ chọn" duy nhất là có bật verify request hay không (`CShieldOptions.verifyRequest`) — một khi đã bật, mọi request vào route được bảo vệ PHẢI mang `cs-proof`, thiếu là `400 CSHIELD_MISSING_SIGNATURE_HEADER`. Không còn luồng RSA dự phòng cho request: thiết bị không ký được bằng hardware key thì không gọi được route được bảo vệ.

### Luồng tích hợp điển hình

```
                         (1) đăng ký thiết bị -> access token ES256 (aud = realm của app)
   Mobile SDK  ───────────────────────────────────────────────▶  CShield cloud
   (Android/iOS)                                                  (ký token bằng khóa realm, công bố JWKS)
        │
        │ (2) mỗi request: ký canonical bằng hardware key -> cs-proof { accessToken, signature, ... }
        ▼
   Server của BẠN (Express + cshield-sdk)  ──(3) tải JWKS 1 lần, cache──▶  CShield cloud
        │          verify OFFLINE: chữ ký token (kid) + aud==realm mình + PoP chữ ký thiết bị (cnf.jwk) + trustLevel
        ▼
   Handler nghiệp vụ -> response ký RSA (cs-timestamp, cs-signature)
```

Phía server bạn chỉ làm **3 việc cấu hình một lần** (xem [Bắt đầu nhanh](#bắt-đầu-nhanh)):
1. **realm** của chính mình — 3 trường lấy từ license + môi trường deploy ([1.1](#11-cấu-hình-realm)).
2. **private key** ký response ([2](#2-ký-response--chữ-ký-rsa)).
3. **minTrustLevel** — ngưỡng tin cậy thiết bị ([1.3](#13-trustpolicy--allowdeny-theo-trustlevel)).

Sau đó mỗi request được verify **hoàn toàn offline** (chỉ tải JWKS lần đầu rồi cache) — không gọi mạng ra ngoài trên đường nóng.

## 1.1 Cấu hình realm

`DefaultRequestVerifier` **bắt buộc** nhận `realm` của chính server — không cần (và không có cách) cấu hình key: public key thiết bị + trustLevel rút từ access token ES256, verify OFFLINE qua JWKS của realm.

```javascript
const { DefaultRequestVerifier, CShieldEnvironment } = require("cshield-sdk");

const verifier = new DefaultRequestVerifier({
  realm: {
    customerCode: "CMCCS",                    // truyền NGUYÊN như trong license
    applicationId: "cshield-embedded-sample", // truyền NGUYÊN như trong license
    environment: CShieldEnvironment.DEV,      // dùng hằng, khỏi gõ tay chuỗi
  },
});
```

`realm` gồm 3 trường, SDK ghép thành `<customerCode>:<applicationId>:<environment>` (viết thường):

| Trường | Mô tả |
|---|---|
| `customerCode` | Mã khách (lấy từ **license** của bạn), vd `CMCCS` |
| `applicationId` | Định danh app (lấy từ **license**), vd `cshield-embedded-sample` — một tenant có thể có nhiều app, mỗi app một realm/khóa ký riêng |
| `environment` | Môi trường instance này phục vụ, vd `DEV` / `STAGING` / `PROD` |

> **Cả 3 trường do SERVER tự pin — KHÔNG lấy từ token client gửi lên.** Chúng là danh tính của *chính server instance* (giống private key ký response), quyết định JWKS/realm được tin và `aud` của token phải khớp (`tenant:<cc>:<app>:<env>`). Nếu lấy từ token, client độc hại chỉ cần khai `aud` tùy ý là vô hiệu hóa việc check — "confused deputy". Pin cứng ở server mới chặn được token cross-app / cross-env.

Các tham số còn lại (optional):

| Tham số | Mặc định | Mô tả |
|---|---|---|
| `requestIdStore` | `new InMemoryRequestIdStore()` | Chống replay theo `requestId`. Mặc định chỉ đúng trong 1 process — xem [1.4](#14-chống-replay-theo-requestid) |
| `clockToleranceSeconds` | `30` | Dung sai đồng hồ cho `exp`/`nbf` của token ES256 |

> **Gốc URL JWKS KHÔNG cấu hình được.** Đó là hạ tầng của CShield (domain nhà cung cấp SDK), không
> liên quan tới bên tích hợp. SDK tải `/api-server/v2/<realm>/.well-known/jwks.json` tại URL **bake
> lúc đóng gói** (cơ chế `gen-base-url`, giống `LICENSE_BASE_URL`): `pack:uat` → `c-shield-license.cmccs.vn`,
> `pack:prod` → `mshield.cmc.vn`. Chọn môi trường = chọn bản build/gói, không phải tham số runtime.

Cửa sổ chống replay theo THỜI GIAN (freshness) cấu hình ở cấp shield — xem [3.4 Cửa sổ chống replay](#34-cửa-sổ-chống-replay).

Cách verify token (tải JWKS theo `kid`, PIN `alg=ES256` chống alg-confusion, check `exp`/`nbf`/`aud`, rút `cnf.jwk` + `lvl`) là chi tiết **NỘI BỘ** — `DefaultRequestVerifier` tự dựng, không nhận `deviceKeyProvider` từ bên ngoài.

## 1.2 Envelope cs-proof

Header `cs-proof` là base64 chuẩn (không url-safe) của một JSON:

```ts
interface CShieldProof {
  accessToken: string;  // access token ES256 (JWT) — mang cnf.jwk (public key thiết bị) + lvl (trustLevel), verify offline qua JWKS
  requestId: string;    // id duy nhất mỗi request — dùng chống replay, xem 1.4
  timestamp: number;    // Unix giây — dùng chống replay theo thời gian, xem 3.4
  requestHash: string;  // bắt buộc có mặt và đúng kiểu (client tự tính); chữ ký verify trên canonicalRequest, không phải field này
  signature: string;    // chữ ký ECDSA (DER, base64) trên canonicalRequest
}
```

`cs-proof` không decode được base64/JSON, không phải object, hoặc thiếu/sai kiểu bất kỳ field bắt buộc nào → `InvalidProofException` (400) — xem [1.5](#15-exception-riêng-của-luồng-này). SDK KHÔNG verify chữ ký hay tính hợp lệ của `accessToken` ở bước parse này, chỉ kiểm tra đúng hình dạng (shape).

`canonicalRequest` — chuỗi thật sự đem đi verify chữ ký ECDSA — ráp từ 6 phần, nối bằng LF:

```
METHOD
PATH
CANONICAL_QUERY
TIMESTAMP
REQUEST_ID
bodyHash
```

`PATH`/`CANONICAL_QUERY` dựng theo đúng thuật toán ở [3.3 Path & query](#33-path--query) — giữ `path`/`canonicalQuery` là 2 dòng riêng (chiều ký response gộp `path?query` thành một field).

## 1.3 TrustPolicy — ALLOW/DENY theo trustLevel

Access token ES256 mang `trustLevel` (claim `lvl`, `"L0"` thấp nhất → `"L5"` cao nhất) của thiết bị. Sau khi chữ ký verify thành công, SDK dùng `TrustPolicy` để quyết định có cho request đi tiếp hay không — mặc định `ThresholdTrustPolicy`, so sánh theo ngưỡng `minTrustLevel`:

```javascript
const shield = new CShield({
  requestVerifier, responseSigner,
  minTrustLevel: "L2", // mặc định "L1" nếu không truyền. KHÔNG được truyền "L0".
});
```

Ngưỡng cấu hình được riêng theo từng route (route không set thì dùng mặc định của `shield`):

```javascript
app.post("/payments", ...shield.middlewares({ minTrustLevel: "L3" }), handler); // route nhạy cảm hơn
app.post("/profile",  ...shield.middlewares(), handler);                        // dùng mặc định của shield
```

`trustLevel = "L0"` LUÔN bị chặn (không phải lựa chọn cấu hình được — truyền `minTrustLevel: "L0"` ném `ConfigurationException` ngay), `trustLevel` lạ/không nhận diện được cũng bị chặn (fail-closed). Cần logic khác "so sánh theo ngưỡng" — xem [4.3 Tùy chỉnh TrustPolicy](#43-tùy-chỉnh-trustpolicy).

### Độ tươi trust — `maxTrustAgeSeconds` (requireFresh)

`minTrustLevel` chỉ hỏi "trust ĐỦ CAO chưa", KHÔNG hỏi "trust có MỚI không". Access token mang claim `fresh` (thời điểm attestor — Play Integrity / App Attest — đánh giá môi trường lần gần nhất). Với mô hình keep-trust ở client (Android), một thiết bị L4 có thể giữ L4 qua nhiều lần refresh KHÔNG chạy lại attestor — nên `fresh` có thể đã cũ dù `trustLevel` vẫn cao.

Route CỰC NHẠY (chuyển tiền lớn, đổi thiết bị...) có thể đòi **bằng chứng attestation tươi tại thời điểm thao tác** qua `maxTrustAgeSeconds` — trust cũ hơn ngưỡng (hoặc token không mang `fresh`) → `StaleTrustException` (403 `CSHIELD_TRUST_NOT_FRESH`), tách riêng khỏi trust-thấp:

```javascript
// Mặc định cho cả instance (tùy chọn — không set = KHÔNG check độ tươi, như trước):
const shield = new CShield({ requestVerifier, responseSigner, minTrustLevel: "L2" });

// Route cực nhạy: đòi L4 + attestation không cũ quá 5 phút.
app.post("/transfer", ...shield.middlewares({ minTrustLevel: "L4", maxTrustAgeSeconds: 300 }), handler);
```

Phía client bắt `CSHIELD_TRUST_NOT_FRESH` → gọi `ensureTrust(..., requireFresh=true)` làm tươi rồi thử lại (tương ứng tín hiệu `fresh_integrity_required` ở luồng refresh BE cloud). Quyết định vẫn ở SERVER: client không set thì server vẫn chặn.

## 1.4 Chống replay theo requestId

Ngoài cửa sổ THỜI GIAN ([3.4](#34-cửa-sổ-chống-replay)), verify request có thêm MỘT lớp: `requestId` trong `cs-proof` phải chưa từng được dùng (dedup).

`InMemoryRequestIdStore` (mặc định) chỉ đúng trong phạm vi **1 process**. Nếu server chạy nhiều instance (k8s nhiều pod, PM2 cluster...), 2 request trùng `requestId` rơi vào 2 pod khác nhau sẽ KHÔNG bị phát hiện (mỗi pod giữ store riêng). Tự implement `RequestIdStore` (`seenRecently(requestId): boolean`, `markSeen(requestId, ttlSeconds): void`) cắm store ngoài (Redis TTL...) nếu cần đúng trên nhiều pod, truyền qua `DeviceVerifyOptions.requestIdStore` ([1.1](#11-không-cần-cấu-hình-gì-thêm)).

`requestId` đã dùng → `ReplayDetectedException` (401). Request bị từ chối vì lý do khác (sai chữ ký, `trustLevel` không đạt...) thì KHÔNG bị đánh dấu dùng — để lần thử lại hợp lệ sau đó (vd sau khi client sửa lỗi) không bị chặn oan vì tưởng là replay.

## 1.5 Exception riêng của verify request

| Exception | Tình huống | status | code | `signable` |
|---|---|:---:|---|:---:|
| `InvalidProofException` | `cs-proof` không base64/JSON hợp lệ hoặc thiếu field | 400 | `CSHIELD_INVALID_PROOF` | `true` |
| `InvalidAccessTokenException` | token ES256 sai/hết hạn/sai `aud`/sai chữ ký/không phải ES256 | 401 | `CSHIELD_INVALID_ACCESS_TOKEN` | `true` |
| `DeviceKeyUnavailableException` | Không tải được JWKS của realm (lỗi/timeout) | 502 | `CSHIELD_DEVICE_KEY_UNAVAILABLE` | `false` |
| `ReplayDetectedException` | `requestId` đã dùng | 401 | `CSHIELD_REPLAY_DETECTED` | `true` |
| `DeviceNotAllowedException` | `trustLevel` bị `TrustPolicy` từ chối | 403 | `CSHIELD_DEVICE_NOT_ALLOWED` | `true` |
| `StaleTrustException` | trust đủ ngưỡng nhưng attestation cũ hơn `maxTrustAgeSeconds` (hoặc thiếu `fresh`) | 403 | `CSHIELD_TRUST_NOT_FRESH` | `true` |

`DeviceKeyUnavailableException` mặc định KHÔNG ký (`signable=false`) — lỗi hạ tầng (không tải được JWKS của realm), không phải lỗi client, cùng triết lý với `ConfigurationException` ([3.5](#35-exception--xử-lý-lỗi)): không tự vouch cho response phát ra khi chính cơ chế verify đang không hoạt động được.

`RequestSignatureMismatchException`, `MalformedRequestException`, `StaleRequestException` dùng chung với chiều ký response — xem bảng đầy đủ ở [3.5](#35-exception--xử-lý-lỗi).

---

# 2. Ký response — Chữ ký RSA

Response được ký bằng RSA-SHA256 với **private key của server** — đây là chỗ duy nhất server cần cấu hình khoá. Client verify bằng public key cùng cặp.

## 2.1 ResponseSigner

`DefaultResponseSigner` ký MỌI response của route được bảo vệ, nhận private key qua `PrivateKeyProvider`:

```javascript
const signer = new DefaultResponseSigner(privateKeyProvider);
```

- Payload ký: `status.path.timestamp.SHA256(body)`
- `sign(bodyHash, status, timestamp, path)` — trả về chữ ký base64.
- Ném `ConfigurationException` nếu private key không load/parse được (lỗi cấu hình server); `ResponseSignerException` nếu key hợp lệ mà thao tác ký vẫn thất bại (hiếm).

Khi dùng qua `CShield`, `sign` được gọi tự động bên trong `signMiddleware`; không cần gọi trực tiếp.

## 2.2 KeyProvider

Lớp trừu tượng cấp khoá PEM private key ký response. SDK gọi `load()` khi cần.

| Provider | Mô tả |
|---|---|
| `PrivateKeyProvider` | Interface một phương thức: `load(): string` |
| `DefaultPrivateKeyProvider(pem)` | Giữ chuỗi PEM truyền thẳng vào |
| `FilePrivateKeyProvider(path)` | Đọc PEM từ file mỗi lần `load()` — hợp k8s mount Secret thành file. Ném `ConfigurationException` nếu file rỗng/không đọc được |
| `CachedKeyProvider(delegate, ttlSeconds = 60)` | Decorator cache `load()` theo TTL — giảm I/O mỗi response được ký, vẫn hot-reload khi Secret xoay vòng. Fail-safe: refresh lỗi tạm thời thì giữ key cũ, không đánh sập việc ký |

```javascript
const privateKeyProvider = new CachedKeyProvider(
  new FilePrivateKeyProvider("/etc/cshield/server-private.pem"),
  60
);
```

> **Không còn `PublicKeyProvider`.** Verify request dùng public key THIẾT BỊ rút từ `cnf.jwk` của access token ES256 (verify offline qua JWKS của realm) — không phải khoá do bên tích hợp cung cấp, nên không có provider nào để cấu hình cho chiều đó.

Nguồn PEM khác (biến môi trường, KMS, secret store...) do phía tích hợp tự implement `load(): string`.

> ⚠️ **`load()` PHẢI trả về một chuỗi PEM dạng văn bản:** `-----BEGIN PRIVATE KEY-----...` (PKCS#8; chấp nhận cả `-----BEGIN RSA PRIVATE KEY-----` PKCS#1).
>
> **KHÔNG** phải base64-của-PEM, **KHÔNG** phải đường dẫn file, **KHÔNG** phải `Buffer`. Nếu lưu base64 trong env var, decode trước khi đưa vào provider:
> ```javascript
> const pem = Buffer.from(process.env.MY_KEY_B64, "base64").toString("utf8"); // -> "-----BEGIN..."
> const provider = new DefaultPrivateKeyProvider(pem);
> ```
> Truyền nhầm base64/đường dẫn/Buffer sẽ làm `crypto` ném lỗi decode (vd `ERR_OSSL_UNSUPPORTED`) hoặc ký thất bại.

---

# 3. Cơ chế chung

## 3.1 CShield & middleware

`CShield` là facade dựng sẵn middleware verify/sign/error từ một cấu hình:

```javascript
const shield = new CShield(options);
```

`options` (`CShieldOptions`):

| Tham số | Kiểu | Mặc định | Mô tả |
|---|---|---|---|
| `requestVerifier` | `RequestVerifier` | bắt buộc | Verify request (chữ ký thiết bị) |
| `responseSigner` | `ResponseSigner` | bắt buộc | Ký response (RSA) |
| `verifyRequest` | `boolean` | `true` | Bật verify request |
| `signResponse` | `boolean` | `true` | Bật ký response |
| `requestTimeoutSeconds` | `number` | `30` | Cửa sổ chống replay, xem [3.4](#34-cửa-sổ-chống-replay) |
| `minTrustLevel` | `"L1"\|"L2"\|"L3"\|"L4"\|"L5"` | `"L1"` | Ngưỡng trustLevel thiết bị — xem [1.3](#13-trustpolicy--allowdeny-theo-trustlevel) |
| `trustPolicy` | `TrustPolicy` | — | Ưu tiên hơn `minTrustLevel` nếu truyền cả hai — xem [4.3](#43-tùy-chỉnh-trustpolicy) |
| `maxTrustAgeSeconds` | `number` | — | "requireFresh" mặc định: tuổi tối đa (giây) của attestation (`fresh`); cũ hơn → 403 `CSHIELD_TRUST_NOT_FRESH`. Không set = không check — xem [1.3](#13-trustpolicy--allowdeny-theo-trustlevel) |
| `onEvent` | `CShieldEventHandler` | — | Hook observability — xem [3.6](#36-observability) |
| `errorWriter` | `CShieldErrorWriter` | `DefaultErrorWriter` | Bộ ghi response lỗi |

Phương thức:

- `shield.middlewares({ bodyHasher?, minTrustLevel?, maxTrustAgeSeconds? })` → mảng `[verifyMiddleware, signMiddleware]` đã dựng sẵn, tuân theo `verifyRequest`/`signResponse` (tắt cái nào thì lược cái đó). Gắn vào route bằng spread `...`. `bodyHasher` đổi cách hash body cho riêng route đó ([3.2](#32-hash-body-theo-loại-route)); `minTrustLevel` override ngưỡng trustLevel riêng cho route đó; `maxTrustAgeSeconds` override "requireFresh" riêng cho route (độ tươi attestation — xem [1.3](#13-trustpolicy--allowdeny-theo-trustlevel)).
- `shield.errorHandler()` → error-handling middleware. Đặt sau toàn bộ route.
- `shield.selfTest()` → parse-check **private key ký response** cho readiness probe (vd endpoint `/readyz`) — CHỈ nạp key qua provider + xác nhận đúng định dạng PEM, KHÔNG ký thật. Ném `ConfigurationException` nếu key rỗng/hỏng/nhầm loại. Không kiểm được chiều verify request: public key là của THIẾT BỊ, rút từ `cnf.jwk` của access token từng request, không có gì cấu hình sẵn để round-trip lúc readiness (nên `verifyRequest=true` một mình không làm `selfTest()` kiểm thêm gì).

```javascript
app.post("/orders", ...shield.middlewares(), handler);
app.use(shield.errorHandler());

app.get("/readyz", (req, res) => {
  try {
    shield.selfTest();
    res.sendStatus(200);
  } catch {
    res.sendStatus(503); // key cấu hình sai -> pod không nhận traffic
  }
});
```

Ba middleware bên dưới lớp `CShield` — dùng trực tiếp khi cần kiểm soát từng route ([4.5](#45-lắp-middleware-rời--tự-viết-middleware)):

- `verifyMiddleware(verifier, { replayGuard?, bodyHasher?, trustPolicy?, onEvent? })` — yêu cầu header `cs-proof`; thiếu → `MissingSignatureHeaderException` (400). Dựng context (parse proof, bodyHash, trustPolicy, cửa sổ tươi) rồi giao cho `verifier.verify()`.
- `signMiddleware(signer)` — ký response bằng RSA. Hook `res.end` nên áp dụng cho `res.json`/`res.send`/`res.end` (response trả một lần; không hỗ trợ response dạng stream nhiều lần `res.write`). Dựng path **ngay khi middleware chạy** (trước cả `next()`) — path hỏng (query percent-encoding sai) → `MalformedRequestException` (400) ngay, KHÔNG chạy tới handler. Nếu path hợp lệ nhưng thao tác ký thất bại lúc `res.end` (key hỏng — hiếm), bỏ ký và log cảnh báo, response vẫn gửi bình thường.
- `errorHandlerMiddleware(errorWriter, onEvent?)` — chỉ xử lý lỗi thuộc `CShieldException`; lỗi khác chuyển tiếp qua `next(err)` để ứng dụng tự xử lý (và đánh dấu để `signMiddleware` không lỡ ký mù response đó).

```javascript
app.post("/ingest", verifyMiddleware(verifier), handler);   // chỉ verify request
app.get("/feed",    signMiddleware(signer), handler);        // chỉ ký response
app.use(errorHandlerMiddleware(new DefaultErrorWriter(signer, true)));
```

## 3.2 Hash body theo loại route

SDK hash **raw bytes** của body trên dây, không hash bản `JSON.stringify(req.body)` dựng lại (cùng một công thức cho cả verify request và ký response). Vì Express phân tích body theo content-type, mỗi loại route **bắt buộc** cấu hình đúng dòng tương ứng:

| Loại route | Cấu hình bắt buộc |
|---|---|
| JSON (POST/PUT) | `express.json({ verify: captureRawBody })` + `shield.middlewares()` |
| Không có body (GET/DELETE) | `shield.middlewares()` |
| `x-www-form-urlencoded` | `express.urlencoded({ verify: captureRawBody })` + `shield.middlewares()` |
| multipart/form-data | `multer` + `shield.middlewares({ bodyHasher: multipartBodyHasher })` |

`captureRawBody` là `verify` hook lưu raw bytes trước khi parse — bắt buộc cho mọi body parser.

```javascript
const multer = require("multer");
const { multipartBodyHasher } = require("cshield-sdk");
const upload = multer();

app.post("/login",  ...shield.middlewares(), handler);  // JSON
app.get("/profile", ...shield.middlewares(), handler);  // không body

// multipart: multer chạy TRƯỚC để tách file khỏi field text, bắt buộc truyền multipartBodyHasher
app.post("/files", upload.any(), ...shield.middlewares({ bodyHasher: multipartBodyHasher }), handler);
```

`defaultBodyHasher` (mặc định) xử lý theo ba nhánh:

1. Có `req.rawBody` → `SHA256(rawBody)`.
2. Không có body trên dây (GET/DELETE, `content-length: 0`) → `EMPTY_BODY_HASH` (= `SHA256` của 0 byte).
3. Có body nhưng thiếu `rawBody` (parser không gắn `captureRawBody`) → ném `ConfigurationException` (500) với thông điệp hướng dẫn, thay vì tạo hash sai (client sẽ ăn 401 khó hiểu nếu fallback âm thầm).

`multipartBodyHasher` chỉ hash các **field text**: sắp xếp key, `JSON.stringify`, rồi `SHA256` (bỏ qua file). Client phải tạo cùng chuỗi JSON (UTF-8, không escape ký tự HTML như `< > & = '`).

## 3.3 Path & query

Chuỗi path/query dùng trong payload ký/verify do `resolveDeviceSignedPath(req)` (verify request, giữ `path`/`canonicalQuery` là 2 dòng riêng) và `resolveResponseSignedPath(req)` (ký response, gộp `path?query` thành 1 field) cung cấp — dùng chung cho MỌI middleware, không middleware nào tự suy ra path riêng. Cả hai hàm dùng CHUNG một thuật toán canonical hoá query, chỉ khác cách ráp cuối.

**Phần path** (trước dấu `?` đầu tiên trong `req.originalUrl`): giữ nguyên bytes gốc trên dây, bao gồm mount prefix (ví dụ `/api`) và phần percent-encoding — không decode, không normalize. Không dùng `req.path` (Express đã decode, và cắt mất mount prefix khi route nằm trong router lồng nhau).

**Phần query** — **có** nằm trong chữ ký, nhưng ký ở dạng **canonical**, không phải bytes thô trên dây:

1. Decode từng cặp `key=value` (percent-decode). Dấu `+` **không** được coi là khoảng trắng (khác quy ước `application/x-www-form-urlencoded`) — chỉ decode đúng `%XX`.
2. Encode lại key và value theo RFC 3986 cố định: giữ nguyên `A-Za-z0-9-_.~`, mọi ký tự khác — kể cả `! ' ( ) *` — encode thành `%XX` với hex viết **HOA**.
3. Sort các cặp theo key đã encode; key trùng nhau thì sort tiếp theo value đã encode.
4. Nối `key=value` bằng `&`. Không có tham số nào → bỏ hẳn dấu `?` (không để lại `?` trơ trọi).

```
req.originalUrl = "/sandbox/transfer?b=2&a=1"
→ canonical query = "a=1&b=2"
```

| Input | Canonical |
|---|---|
| (không có query) | (không có `?`) |
| `?` (query rỗng) | (không có `?` — coi như không có query) |
| `file=a%2Fb` hoặc `file=a%2fb` | `file=a%2Fb` (hex luôn viết hoa) |
| `%61mount=100` hoặc `amount=100` | `amount=100` (bỏ encode thừa ký tự không bắt buộc) |
| `q=hi!` | `q=hi%21` |
| `q=a+b` | `q=a%2Bb` (không phải `"a b"`) |

**Vì sao canonical hoá thay vì ký raw bytes:** proxy/CDN/WAF đứng trước server hay viết lại query (sort tham số để cache, decode/re-encode khi inspect) mà không đổi nội dung. Ký raw sẽ khiến request hợp lệ bị `401` oan mỗi khi hạ tầng phía trước đổi cách **biểu diễn** query. Canonical hoá bất biến với thứ tự/cách encode, chỉ nhạy với **giá trị** thật — đổi giá trị (kể cả sau khi ký) vẫn bị chặn.

**Client (SDK khác ngôn ngữ, không nằm trong package này) phải cài đúng thuật toán trên** — dựng canonical query từ danh sách tham số **định gửi**, không parse lại một URL string đã build sẵn (tránh lệch thứ tự/encoding). Response cũng ký lại bằng đúng `path` (kèm canonical query) của chính request đã gửi — không có khái niệm "path của response" riêng.

**Query hỏng percent-encoding** (`%zz`, `%` cụt...) làm cả hai hàm resolve ném `MalformedRequestException` (400, `CSHIELD_MALFORMED_REQUEST`) — khác hẳn "chữ ký không khớp":

- Ở `verifyMiddleware` — request bị từ chối ngay, `400 CSHIELD_MALFORMED_REQUEST`.
- Ở `signMiddleware` — cũng bị chặn ngay từ đầu (validate trước `next()`), trả `400 CSHIELD_MALFORMED_REQUEST`, handler **không chạy tới** — dù route đó chỉ dùng `signMiddleware`, không có `verifyMiddleware` đứng trước.
- Ở `errorHandlerMiddleware` — khi cần ký MỘT response lỗi khác mà việc dựng lại path cũng gặp query hỏng, SDK tự bắt lỗi, fallback ký bằng path không kèm query — không để lỗi này đè lên lỗi gốc.

## 3.4 Cửa sổ chống replay

`ReplayGuard` kiểm tra timestamp nằm trong cửa sổ thời gian cho phép: `Math.abs(now - timestamp) <= window` (đối xứng — từ chối cả timestamp quá khứ lẫn tương lai):

```javascript
const guard = new ReplayGuard(30); // cửa sổ 30 giây (mặc định)
guard.isFresh(timestamp);          // boolean
guard.assertFresh(timestamp);      // ném StaleRequestException nếu ngoài cửa sổ
```

**Một cửa sổ duy nhất cho toàn bộ shield** — `CShieldOptions.requestTimeoutSeconds` (hoặc `options.replayGuard` khi lắp `verifyMiddleware` rời). `verifyMiddleware` truyền giá trị này vào `ctx.freshnessSeconds` để core check `proof.timestamp`, VÀ dùng luôn nó làm TTL cho dedup `requestId` ([1.4](#14-chống-replay-theo-requestid)) — một chỗ cấu hình duy nhất cho cả hai lớp chống replay.

## 3.5 Exception & xử lý lỗi

`errorHandlerMiddleware` dùng `errorWriter` để ghi response cho lỗi thuộc `CShieldException`. Lỗi KHÔNG thuộc `CShieldException` (bug nghiệp vụ, exception tự viết không kế thừa) được chuyển tiếp nguyên vẹn cho `next(err)` — SDK không "nuốt" hay ký thay các lỗi này.

`DefaultErrorWriter` trả về body:

```json
{ "success": false, "code": "...", "message": "..." }
```

với HTTP status lấy từ exception, và ký response nếu `signResponse = true` **và** exception đó `signable = true`.

### `signable` — quyết định có ký response lỗi hay không

Mỗi `CShieldException` tự mang thêm field `signable: boolean` (mặc định `true`), **độc lập với `status`** — cố tình không suy luận "status ≥ 500 thì không ký", vì status chỉ mô tả *lỗi của ai* (client/server), không mô tả *có nên ký hay không*. Một exception nghiệp vụ tự viết (status 503 chẳng hạn) hoàn toàn có thể muốn ký; chỉ các exception hạ tầng của chính CShield (`ConfigurationException`, `ResponseSignerException`, `DeviceKeyUnavailableException`) mặc định tắt.

### Bảng exception đầy đủ

| Exception | Tình huống | status | code | `signable` |
|---|---|:---:|---|:---:|
| `MissingSignatureHeaderException` | thiếu header `cs-proof` | 400 | `CSHIELD_MISSING_SIGNATURE_HEADER` | `true` |
| `InvalidProofException` | `cs-proof` không hợp lệ hoặc thiếu field | 400 | `CSHIELD_INVALID_PROOF` | `true` |
| `MalformedRequestException` | path/query không dựng được canonical form (query hỏng percent-encoding) | 400 | `CSHIELD_MALFORMED_REQUEST` | `true` |
| `RequestSignatureMismatchException` | proof dựng được, key thiết bị hợp lệ, nhưng chữ ký không khớp | 401 | `CSHIELD_SIGNATURE_MISMATCH` | `true` |
| `StaleRequestException` | timestamp ngoài cửa sổ chống replay | 401 | `CSHIELD_STALE_REQUEST` | `true` |
| `InvalidAccessTokenException` | `accessToken` sai/hết hạn | 401 | `CSHIELD_INVALID_ACCESS_TOKEN` | `true` |
| `ReplayDetectedException` | `requestId` đã dùng | 401 | `CSHIELD_REPLAY_DETECTED` | `true` |
| `DeviceNotAllowedException` | `trustLevel` bị `TrustPolicy` từ chối | 403 | `CSHIELD_DEVICE_NOT_ALLOWED` | `true` |
| `StaleTrustException` | attestation cũ hơn `maxTrustAgeSeconds` (hoặc thiếu `fresh`) | 403 | `CSHIELD_TRUST_NOT_FRESH` | `true` |
| `ConfigurationException` | private key không load/parse được, thiếu `rawBody`, `minTrustLevel` sai... | 500 | `CSHIELD_MISCONFIGURED` | `false` |
| `ResponseSignerException` | key hợp lệ nhưng thao tác ký vẫn thất bại (hiếm) | 500 | `CSHIELD_RESPONSE_SIGN_FAILED` | `false` |
| `DeviceKeyUnavailableException` | không lấy được public key thiết bị (remote lỗi/timeout) | 502 | `CSHIELD_DEVICE_KEY_UNAVAILABLE` | `false` |

`ResponseSigner.sign()` phân biệt theo **nguyên nhân gốc**: private key không load/parse được (server cấu hình sai) → `ConfigurationException` (500); key hợp lệ nhưng thao tác ký thất bại → `ResponseSignerException` (500). Phía verify request, `DeviceKeyUnavailableException` (502) là "không lấy được key thiết bị" (hạ tầng), còn `RequestSignatureMismatchException` (401) là "lấy key được nhưng chữ ký không khớp" (lỗi client).

### Lỗi KHÔNG phải `CShieldException` không bao giờ được ký

Route có `verifyMiddleware` + `signMiddleware`, verify đã pass, nhưng handler tự ném 1 lỗi nghiệp vụ thường (không kế thừa `CShieldException`) — response cuối cùng (thường là trang lỗi mặc định của Express) **không được ký**, dù `signMiddleware` đã hook `res.end` từ trước. `errorHandlerMiddleware` đánh dấu điều này ngay khi nhận diện lỗi lạ — tránh ký nhầm 1 response không do CShield tạo ra (có thể leak stack trace nội bộ kèm chữ ký hợp lệ, gây hiểu lầm cho client).

Ngược lại, handler tự `res.status(400).json({...})` **không throw gì cả** (lỗi nghiệp vụ thuần, vd OTP sai) vẫn được ký bình thường — bất kể HTTP status do handler tự chọn là gì.

## 3.6 Observability

`onEvent` (tuỳ chọn — `CShieldOptions`, hoặc trực tiếp trên `verifyMiddleware`/`errorHandlerMiddleware`) nhận callback mỗi khi có sự kiện verify — để tăng counter Prometheus, log JSON, gửi APM:

```javascript
const { jsonStdoutEventHandler } = require("cshield-sdk");
const shield = new CShield({ ..., onEvent: jsonStdoutEventHandler }); // log JSON ra stdout sẵn
```

Handler PHẢI không-ném và rẻ — chạy trên hot path của mỗi request. Các loại sự kiện (`CShieldEventType`), tên cố định (snake_case) để dùng trực tiếp làm nhãn Prometheus/field ELK:

`request_verified`, `invalid_signature`, `stale_request`, `missing_header`, `malformed_request`, `misconfigured`, `internal_error`, `invalid_proof`, `invalid_access_token`, `device_key_unavailable`, `replay_detected`, `device_not_allowed`, `error` (fallback cho `CShieldException` chưa map).

`eventTypeForError(err)` suy ra loại sự kiện từ một `CShieldException` bất kỳ — dùng khi tự viết `CShieldErrorWriter` ([4.4](#44-tùy-chỉnh-response-lỗi)) mà vẫn muốn giữ observability mặc định.

---

# 4. Tùy chỉnh

| Hạng mục | Áp dụng cho | Cách |
|---|---|---|
| Chuỗi payload ký response | Ký response | Kế thừa `ResponseSigner`, override `buildPayload()` |
| Nguồn private key | Ký response | Implement `PrivateKeyProvider` |
| TrustPolicy | Verify request | Implement `TrustPolicy` |
| Response lỗi | Cả 2 chiều | Kế thừa `CShieldErrorWriter`, override `writeError()` |
| Cửa sổ thời gian | Verify request | `requestTimeoutSeconds` hoặc `new ReplayGuard(n)` |
| Chống replay theo `requestId` | Verify request | Implement `RequestIdStore`, truyền qua `DeviceVerifyOptions` |
| Bật/tắt verify hoặc sign | Cả 2 chiều | `verifyRequest` / `signResponse` |
| Logic crypto `verify()` / `sign()` | Cả 2 chiều | Không — bị niêm phong (sealed) |
| Canonical request / tên header `cs-proof` / nguồn lấy device key | Verify request | Không — cố định theo spec, không có điểm override |

## 4.1 Tùy chỉnh payload ký response

`ResponseSigner` là abstract class đã cài đặt sẵn phần crypto. Điểm override duy nhất là `buildPayload()` — chuỗi đem đi ký. Chuỗi payload phải khớp tuyệt đối với cách client verify response.

```javascript
const { ResponseSigner } = require("cshield-sdk");

class CustomResponseSigner extends ResponseSigner {
  buildPayload(bodyHash, status, timestamp, path) {
    return `custom.${status}.${path}.${timestamp}.${bodyHash}`;
  }
}

const shield = new CShield({
  requestVerifier: new DefaultRequestVerifier(),
  responseSigner:  new CustomResponseSigner(privateKeyProvider),
});
```

Phương thức `sign()` bị niêm phong: cố override sẽ ném lỗi ngay lúc khởi tạo. Đây là chủ đích để bảo toàn logic crypto — chỉ `buildPayload()` được phép thay đổi.

**Không có bản tương đương cho verify request.** `RequestVerifier.verify()` cũng bị niêm phong và `RequestVerifier` KHÔNG còn điểm override nào — canonical request cố định theo spec AIP v2, vì client ký bằng key phần cứng theo đúng một định dạng thống nhất.

## 4.2 Tùy chỉnh KeyProvider

Implement interface `load(): string` để lấy private key ký response từ nguồn bất kỳ (KMS, Vault, database, biến môi trường...).

```javascript
class KmsPrivateKeyProvider {
  load() {
    return fetchPemFromKms(); // trả về chuỗi PEM
  }
}

const signer = new DefaultResponseSigner(new KmsPrivateKeyProvider());
```

## 4.3 Tùy chỉnh TrustPolicy

Cần logic khác đơn giản "so sánh theo ngưỡng" ([1.3](#13-trustpolicy--allowdeny-theo-trustlevel)) — tự viết `TrustPolicy` (`evaluate(trustLevel, ctx): "ALLOW" | "DENY"`) và truyền qua `trustPolicy` (ưu tiên hơn `minTrustLevel` nếu truyền cả hai):

```javascript
const shield = new CShield({
  requestVerifier, responseSigner,
  trustPolicy: { evaluate: (trustLevel) => (trustLevel === "L3" ? "ALLOW" : "DENY") },
});
```

## 4.4 Tùy chỉnh response lỗi

Mặc định (`DefaultErrorWriter`) trả body `{ success: false, code, message }` với status và message lấy thẳng từ exception (xem [3.5](#35-exception--xử-lý-lỗi)). Kế thừa `CShieldErrorWriter` và override `writeError(res, err, reqPath)` để **đổi status, code, message, hoặc shape body**. `err` đã mang sẵn `status`, `code`, `message`.

Tất cả exception đều kế thừa `CShieldException`. Dùng `switch` trên `err.constructor` để rẽ theo từng loại (case là chính class exception nên IDE bắt được nếu gõ sai tên), nhánh `default` xử lý `CShieldException` gốc và mọi exception tự định nghĩa. `signable` mặc định lấy từ `err.signable` nhưng override được y hệt status/code/message — writer tự quyết định cuối cùng có gọi `attachSignature` hay không, SDK không ép:

```javascript
const {
  CShieldErrorWriter,
  MissingSignatureHeaderException,
  RequestSignatureMismatchException,
  StaleRequestException,
  ResponseSignerException,
  ConfigurationException,
} = require("cshield-sdk");

class CustomErrorWriter extends CShieldErrorWriter {
  writeError(res, err, reqPath) {
    let status = err.status;
    let code = err.code;
    let message = err.message;
    let signable = err.signable; // mặc định lấy từ exception, nhưng CÓ THỂ override

    switch (err.constructor) {
      case MissingSignatureHeaderException:
        status = 400; code = "MISSING_SIGNATURE"; message = "Thiếu chữ ký"; break;
      case RequestSignatureMismatchException:
        status = 403; code = "INVALID_SIGNATURE"; message = "Chữ ký không hợp lệ"; break;
      case StaleRequestException:
        status = 408; code = "EXPIRED"; message = "Phiên đã hết hạn, vui lòng thử lại"; break;
      case ResponseSignerException:
        status = 500; code = "SIGN_ERROR"; message = "Lỗi ký phản hồi"; break;
      case ConfigurationException:
        status = 500; code = "MISCONFIGURED"; message = "Lỗi cấu hình máy chủ";
        signable = true; // vd: muốn ký cả lỗi cấu hình để có bằng chứng mật mã khi audit
        break;
      default:
        break; // exception khác → giữ status/code/message/signable mặc định của chính nó
    }

    const body = JSON.stringify({ ok: false, errorCode: code, detail: message });

    res.status(status).setHeader("Content-Type", "application/json");
    if (this.signResponse && signable) this.attachSignature(res, body, status, reqPath);
    res.send(body);
  }
}

const shield = new CShield({
  requestVerifier,
  responseSigner,
  errorWriter: new CustomErrorWriter(responseSigner, true), // (signer, signResponse)
});
```

`attachSignature(res, body, status, path)` (kế thừa từ lớp cha) ký body lỗi và gắn header chữ ký — luôn truyền đúng `status`/`body` bạn thực sự gửi để client verify khớp.

## 4.5 Lắp middleware rời / tự viết middleware

Khi cần kiểm soát ở mức route — chỉ verify hoặc chỉ sign, cửa sổ thời gian riêng, đổi tên header, hoặc đổi cách lấy path — lắp trực tiếp middleware hoặc gọi thẳng core.

```javascript
const {
  verifyMiddleware, signMiddleware, ReplayGuard,
  parseCShieldProof, defaultBodyHasher, ThresholdTrustPolicy,
} = require("cshield-sdk");

// Cửa sổ thời gian riêng cho route nhạy cảm (xem 3.4).
app.post("/payments",
  verifyMiddleware(verifier, { replayGuard: new ReplayGuard(10) }),
  signMiddleware(signer),
  handler
);

// Tự gọi thẳng core verifier (vd lấy proof từ nguồn khác header `cs-proof`).
// `verify()` là async, nhận 1 context object — xem "Tham chiếu API" > RequestVerifier
// để biết đủ field của VerifyContext.
app.use(async (req, res, next) => {
  try {
    await verifier.verify({
      req,
      proof: parseCShieldProof(proofFromSomewhere(req)),
      bodyHash: defaultBodyHasher(req),
      trustPolicy: new ThresholdTrustPolicy("L2"),
      freshnessSeconds: 30,
    });
    next();
  } catch (err) {
    next(err);
  }
});
```

---

## Tham chiếu API

Facade & middleware:

| Export | Mô tả |
|---|---|
| `CShield` | Facade: `middlewares({ bodyHasher?, minTrustLevel? })`, `errorHandler()`, `selfTest()` |
| `verifyMiddleware(verifier, { replayGuard?, bodyHasher?, trustPolicy?, onEvent? })` | Middleware verify request — yêu cầu header `cs-proof` |
| `signMiddleware(signer)` | Middleware ký response (RSA) |
| `errorHandlerMiddleware(errorWriter, onEvent?)` | Middleware xử lý `CShieldException` |

Core verify/sign:

| Export | Mô tả |
|---|---|
| `RequestVerifier` / `DefaultRequestVerifier` | Verify chữ ký thiết bị. Constructor nhận `DeviceVerifyOptions` — `realm` (bắt buộc, 3 trường), `requestIdStore?`, `clockToleranceSeconds?` — xem [1.1](#11-cấu-hình-realm). Gốc URL JWKS + claim `iss` KHÔNG cấu hình được (của CShield cloud). `verify(ctx)` async, sealed — `ctx: VerifyContext` (`{ req, proof, bodyHash, trustPolicy, freshnessSeconds }`). Không có điểm override nào |
| `ResponseSigner` / `DefaultResponseSigner` | Ký response; override `buildPayload()`; `sign()` sealed |

Key provider (private key ký response):

| Export | Mô tả |
|---|---|
| `PrivateKeyProvider` | Interface `load(): string` |
| `DefaultPrivateKeyProvider` | Giữ chuỗi PEM truyền vào |
| `FilePrivateKeyProvider` | Đọc PEM từ file mỗi `load()` |
| `CachedKeyProvider` | Decorator cache `load()` theo TTL |

Replay & path:

| Export | Mô tả |
|---|---|
| `ReplayGuard` | `new ReplayGuard(seconds)`, `isFresh()`, `assertFresh()` |
| `RequestIdStore` (interface) / `InMemoryRequestIdStore` | Chống replay theo `requestId` — xem [1.4](#14-chống-replay-theo-requestid) |
| `resolveDeviceSignedPath(req)` | Path raw (giữ mount prefix) + query canonical hoá, giữ `path`/`query` là 2 dòng riêng — verify request |
| `resolveResponseSignedPath(req)` | Giống trên nhưng nối `path?query` thành 1 field — ký response |

Trust & proof (verify request):

| Export | Mô tả |
|---|---|
| `TrustPolicy` (interface) / `ThresholdTrustPolicy` / `CShieldTrustLevel` | ALLOW/DENY theo trustLevel — xem [1.3](#13-trustpolicy--allowdeny-theo-trustlevel) |
| `CShieldProof` (type) / `parseCShieldProof(header)` | Envelope `cs-proof` + parser (base64 → JSON, validate field) |
| `buildCanonicalRequest(req, timestamp, requestId, bodyHash)` | Ráp canonical request (6 thành phần, LF) — xem [1.2](#12-envelope-cs-proof) |
| `EcdsaVerifier` | Verify chữ ký ECDSA P-256/SHA-256 thuần (nhận `KeyObject` sẵn, không tự parse SPKI) |

**Không export** (chi tiết NỘI BỘ — `RequestVerifier` tự dựng, không phải API cho bên tích hợp cấu hình/thay thế): `DeviceKeyProvider`, `EsDeviceKeyProvider` (`src/internal/device_key/`), `EsAccessTokenVerifier` (`src/internal/token/`). Cách verify token ES256 offline qua JWKS của realm là chi tiết nội bộ.

Body & hash:

| Export | Mô tả |
|---|---|
| `captureRawBody` | `verify` hook lưu raw bytes; gắn vào mọi body parser |
| `defaultBodyHasher` | Hasher mặc định (rawBody / empty / lỗi cấu hình) |
| `multipartBodyHasher` | Hasher cho route multipart |
| `normalizeMultipartBody(fields)` | Chuẩn hóa field text multipart (sort key + JSON) |
| `EMPTY_BODY_HASH` | Hash của body rỗng (0 byte) |
| `requestHasBody(req)` | Phát hiện request có body trên dây |
| `Sha256` | `hash()`, `hashObject()`, `hashBuffer()` |

Error handling:

| Export | Mô tả |
|---|---|
| `CShieldErrorWriter` / `DefaultErrorWriter` | Ghi response lỗi |

Observability:

| Export | Mô tả |
|---|---|
| `CShieldEventHandler` / `CShieldEventType` | Callback + loại sự kiện — xem [3.6](#36-observability) |
| `eventTypeForError(err)` | Suy ra `CShieldEventType` từ một `CShieldException` |
| `jsonStdoutEventHandler` | Handler dựng sẵn: log mỗi sự kiện thành JSON ra stdout |

Exception — chi tiết đầy đủ ở [3.5](#35-exception--xử-lý-lỗi):

| Export | status | code |
|---|:---:|---|
| `CShieldException` | (lớp cơ sở, có field `status`/`code`/`signable`) | — |
| `MissingSignatureHeaderException` | 400 | `CSHIELD_MISSING_SIGNATURE_HEADER` |
| `InvalidProofException` | 400 | `CSHIELD_INVALID_PROOF` |
| `MalformedRequestException` | 400 | `CSHIELD_MALFORMED_REQUEST` |
| `RequestSignatureMismatchException` | 401 | `CSHIELD_SIGNATURE_MISMATCH` |
| `StaleRequestException` | 401 | `CSHIELD_STALE_REQUEST` |
| `InvalidAccessTokenException` | 401 | `CSHIELD_INVALID_ACCESS_TOKEN` |
| `ReplayDetectedException` | 401 | `CSHIELD_REPLAY_DETECTED` |
| `DeviceNotAllowedException` | 403 | `CSHIELD_DEVICE_NOT_ALLOWED` |
| `StaleTrustException` | 403 | `CSHIELD_TRUST_NOT_FRESH` |
| `ConfigurationException` | 500 | `CSHIELD_MISCONFIGURED` |
| `ResponseSignerException` | 500 | `CSHIELD_RESPONSE_SIGN_FAILED` |
| `DeviceKeyUnavailableException` | 502 | `CSHIELD_DEVICE_KEY_UNAVAILABLE` |
